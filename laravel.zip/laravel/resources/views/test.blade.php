@extends('layout.main')

@section('content')

<div class="container-fluid bg-primary py-5">
	<div class="row">
		<div class="col-md-12 col-lg-6 bg-info">
			test
		</div>

		<div class="col-md-12 col-lg-6 bg-danger">
			test1
		</div>

	</div>
</div>

@endsection