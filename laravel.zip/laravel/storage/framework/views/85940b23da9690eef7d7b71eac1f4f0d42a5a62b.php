


<?php $__env->startSection('title'); ?>
Daftar Booking | Mitra SiBengkel
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

<div class="row">
  <div class="col-md-12">
    <div class="card">
      <div class="card-header">
        <h4 class="card-title"> Daftar Booking</h4>
      </div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table" id='table' >
            <thead class=" text-primary">
              <th>ID</th>
              <th>Nama</th>
              <th>Jenis Service</th>
              <th>Jadwal Booking</th>
              <th>Income</th>
            </thead>
            <tbody>
              <?php $__currentLoopData = $tb_booking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


              <tr>
                <td><?php echo e($row->id); ?></td>
                <td><?php echo e($row->namabengkel->name); ?></td>
                <td><?php echo e($row->namaservis->nama_servis); ?> </td>
                <td><?php echo e($row->jadwal); ?></td>
                <td>
                  <?php if($row->revenue > 0): ?>
                      
                 <?php echo e($row->revenue); ?> 
                  <?php else: ?>
                  <div class="input-group mb-3">
                    <input type="number" class="form-control" placeholder="Contoh: 100000" aria-label="Income" aria-describedby="basic-addon2" id="<?php echo e('revenue'.$row->id); ?>">
                    <div class="input-group-append">
                      <button class="btn primary revenue-enter" id="<?php echo e($row->id); ?>" type="button">Enter </button>
                    </div>
                  </div>
                  <?php endif; ?>
                 
                  
                </td>
              </tr>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
  
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<script type="text/javascript"> 

  $(document).ready(function(){
    $('#table').DataTable(); 
    $('.revenue-enter').on('click',function(){

      var id_booking = $(this).attr('id');
      $.ajaxSetup({
        headers: {
        'X-CSRF-TOKEN' : $('meta[name="csrf-token"]').attr('content')

        }   
      })
      var revenue = $('#revenue'+id_booking).val();
      $.post( "/revenue", { id_booking: id_booking, revenue: revenue })
      .done(function( data ) {
        alert( "Revenue Added" );
      });
    });

  
});

</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TA\resources\views/admin/booking.blade.php ENDPATH**/ ?>