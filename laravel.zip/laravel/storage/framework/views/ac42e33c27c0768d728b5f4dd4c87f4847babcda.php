


<?php $__env->startSection('title'); ?>
    edit
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title"> Update </h4>

                <form action= <?php echo e(url('editbarang/'.$editbarang->id)); ?>  method="POST" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

            
                    <div class="form-group">
                        <label for="recipient-name" class="col-form-label">Nama</label>
                        <input value="<?php echo e($editbarang->nama); ?>" type="text" name="nama" class="form-control" id="recipient-name">
                      </div>
                      <p> ID Jenis Barang </p>
                      <select name='jenisbarang' class="form-control">
                        <?php $__currentLoopData = $jenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($value->id); ?>" <?php if($value->id==$editbarang->jenis_id): ?> selected  <?php endif; ?>><?php echo e($value->namajenis); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                      </select>
                      <div class="form-group">
                        <label for="message-text" class="col-form-label">Deskripsi</label>
                        <textarea name="deskripsi" class="form-control" id="message-text"> <?php echo e($editbarang->deskrip); ?> </textarea>
                      </div>
                      <div class="form-group">
                        <label for="recipient-name" class="col-form-label">Stock</label>
                        <input value="<?php echo e($editbarang->stock); ?>" type="number" name="stock" class="form-control" id="recipient-name">
                      </div>
                      <div class="form-group">
                        <label for="recipient-name" class="col-form-label">Harga</label>
                        <input value="<?php echo e($editbarang->harga); ?>" type="number" name="harga" class="form-control" id="recipient-name">
                      </div>
                      <img src="<?php echo e(url($editbarang->gambar_b)); ?>">
                      <input type="file" name ='gambar' class="form-control" id="customFile">

                      <a href="<?php echo e(url('input')); ?>" class="btn btn-secondary">Back</a>
                      <button type="submit" class="btn btn-primary">Save</button>
                      
                </form>

            </div>
        </div>
    </div>
</div>    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TA\resources\views/admin/edit.blade.php ENDPATH**/ ?>