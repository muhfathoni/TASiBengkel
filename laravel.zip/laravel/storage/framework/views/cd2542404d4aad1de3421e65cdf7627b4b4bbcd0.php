

<?php $__env->startSection('content'); ?>

<div class="container-fluid bg-primary py-5">
	<div class="row">
		<div class="col-md-12 col-lg-6 bg-info">
			test
		</div>

		<div class="col-md-12 col-lg-6 bg-danger">
			test1
		</div>

	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Program File\xampp\htdocs\TASiBengkel\resources\views/test.blade.php ENDPATH**/ ?>