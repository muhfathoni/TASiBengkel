<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body class="animsition">

	<?php echo $__env->make('layout.top-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	
	
	<?php echo $__env->yieldContent('content'); ?>


	<!-- Footer -->
	<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<?php echo $__env->yieldPushContent('script'); ?>


</body>
</html>
<?php /**PATH C:\xampp\htdocs\BlogLaravel\resources\views/layout/main.blade.php ENDPATH**/ ?>