

<?php $__env->startSection('title'); ?>
Booking
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
	<section style="background: url('img/background-mitra.jpg'); height: 300px;">
		<div class="text-center text-white" style="text-shadow: #0b0b0b 3px 3px"
		">
		<h1 class="text-uppercase">
			<strong>Booked Service</strong>
		</h1>
	</div>
</section>
</div>
<!-- <?php if(count($errors)>0): ?>
<div class="alert alert-danger">
	<ul>
		<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<li>
			<?php echo e($error); ?>

		</li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ul>
</div>
<?php endif; ?>
<?php if(\Session::has('success')): ?>
<div class="alert alert-success">
	<p>
		<?php echo e(\Session::get('success')); ?>

	</p>
</div>
<?php endif; ?> -->

<center>
	<div class="table-responsive">
		<div class="container"> 
			<table class="table">
				<tr>
					<th>Booked Service</th>
					<th>Nama Bengkel</th>
					<th>Jadwal</th>
					<th>Jam</th>
					<th>Action</th>
				</tr>

				<?php $__currentLoopData = $booking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

				<tr>
					<td>
						<?php echo e($booking->namaservis->nama_servis); ?>

					</td>
					<td>
						<?php echo e($booking->namabengkel->name); ?>

					</td>
					<td>
						<?php echo e($booking->jadwal); ?>

					</td>
					<td>
						<?php echo e($booking->jam); ?>

					</td>
					<td>
						<button class="btn btn-sm btn-danger hapus-barang" type="button" id="<?php echo e($booking->id); ?>" onclick="deleteFunction(<?php echo e($booking->id); ?>)">
							<i class="fa fa-trash" aria-hidden="true"></i> Hapus
						</button>
					</td>
				</tr>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
		</div>
	</div>
</center>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset ('css/creative.min.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script type="text/javascript">
	$(document).ready(function(){
		$('#bengkel').on('click', function(){
			let id = $(this).val()

			if (id!=''){
				$.get('optionbooking/'+id, function(response){
					$('#namaService').html(response)
				})
			}
		})
	})

	function deleteFunction(id){
		swal({
			title: "Are you sure?",
			text: "Once deleted, you will not be able to recover this product",
			icon: "warning",
			buttons: true,
			dangerMode: true,
		})
		.then((willDelete) => {
			if (willDelete) {
				$.get('booking/'+id, function(response){
					swal("Your booking has been deleted!",{
						icon: "success", 
						buttons: true,
					})
					.then((deleted)=>{
						window.location.reload();
					});
				})
			} else {
				swal("Your booking has not been deleted");
			}
		})
	}
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TA\resources\views/booking.blade.php ENDPATH**/ ?>