


<?php $__env->startSection('title'); ?>
    Input Barang
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Input Barang</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="/tambahbarang" method="POST" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>


      <div class="modal-body">
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Nama</label>
            <input type="text" name="nama" class="form-control" id="recipient-name">
          </div>
          <p> ID Jenis Barang </p>
          <select name='jenisbarang' class="form-control">
            <?php $__currentLoopData = $jenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($value->id); ?>"><?php echo e($value->namajenis); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
          </select>
          <div class="form-group">
            <label for="message-text" class="col-form-label">Deskripsi</label>
            <textarea name="deskripsi" class="form-control" id="message-text"></textarea>
          </div>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Stock</label>
            <input type="number" name="stock" class="form-control" id="recipient-name">
          </div>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Harga</label>
            <input type="number" name="harga" class="form-control" id="recipient-name">
          </div>
          <input type="file" name ='gambar' class="form-control" id="customFile">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save</button>
      </div>
    </form>

    </div>
  </div>
</div>

<div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <h4 class="card-title"> Input Barang 
                  <button type="button" class="btn btn-primary float-right" data-toggle="modal" data-target="#exampleModal">+</button>

                </h4>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="display nowrap" id='tableinput'>
                    <thead class=" text-primary">
                      <th>Nama Barang</th>
                      <th>Jenis Barang</th>
                      <th>Stock</th>
                      <th>Harga</th>
                      <th>Gambar</th>
                      <th>EDIT</th>
                      <th>DELETE</th>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                              <td><?php echo e($row->nama); ?></td>
                              <td><?php echo e($row->jenis->namajenis); ?></td>
                              <td><?php echo e($row->stock); ?></td>
                              <td><?php echo e($row->harga); ?></td> 
                              <td> <img src="<?php echo e(url($row->gambar_b)); ?>"></td>
                        <td> 
                        <a href="editbarang/<?php echo e($row->id); ?>" class="btn btn-success">EDIT</a> 
                        
                        </td>
                        <td> 
                        <a href="deletebarang/<?php echo e($row->id); ?>" class="btn btn-danger">DELETE</a> 
                        
                        </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    
                  </table>
                </div>
              </div>
            </div>
          </div>
                  
          

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<script>
$(document).ready( function () {
    $('#tableinput').DataTable({
      scrollX: true
    });

    $('#editbarang').on('show.bs.modal', function (event) {
  var button = $(event.relatedTarget) // Button that triggered the modal
  var recipient = button.data('barang') // Extract info from data-* attributes
  // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
  // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
  var modal = $(this)
  modal.find('.modal-title').text('New message to ' + recipient)
  modal.find('.modal-body input').val(recipient)
})

} );

</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Program File\xampp\htdocs\TASiBengkel\resources\views/admin/input.blade.php ENDPATH**/ ?>