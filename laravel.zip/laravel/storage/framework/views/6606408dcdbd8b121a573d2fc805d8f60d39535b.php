	<footer class="bg6 p-t-45 p-b-43 p-l-45 p-r-45">
		<div class="flex-w p-b-90">
			<div class="w-size6 p-t-30 p-l-15 p-r-15 respon3 col-5 text-justify">
				<h4 class="s-text12 p-b-30">
					GET IN TOUCH
				</h4>

				<div>
					<p class="s-text7 w-size27">
					Any questions? Call us on (+62) 812 1451 1102 </br>
					or email us at sibengkel@sibengkel.com
				</p>
			</div>
		</div>

		<div class="w-size7 p-t-30 p-l-15 p-r-15 respon4 col-1 text-justify">
			<h4 class="s-text12 p-b-30 p-l-50">
				Categories
			</h4>

			<ul>
				<li class="p-b-9">
					<a href="#" class="s-text7">
						Helmet
					</a>
				</li>

				<li class="p-b-9">
					<a href="#" class="s-text7">
						Jacket
					</a>
				</li>

				<li class="p-b-9">
					<a href="#" class="s-text7">
						Gloves
					</a>
				</li>

				<li class="p-b-9">
					<a href="#" class="s-text7">
						Tires
					</a>
				</li>

				<li class="p-b-9">
					<a href="#" class="s-text7">
						Lamp
					</a>
				</li>
			</ul>
		</div>
		<div class="w-size7 p-t-30 p-l-15 p-r-15 respon4 col-4 text-justify">
			<h4 class="s-text12 p-b-30">
				 
			</h4>
			<h4 class="s-text12 p-b-30">
				 
			</h4>
			<ul>
				<li class="p-b-9">
					<a href="#" class="s-text7">
						Belt
					</a>
				</li>

				<li class="p-b-9">
					<a href="#" class="s-text7">
						Windshield
					</a>
				</li>

				<li class="p-b-9">
					<a href="#" class="s-text7">
						Exhaust
					</a>
				</li>

				<li class="p-b-9">
					<a href="#" class="s-text7">
						Lamp
					</a>
				</li>
			</ul>
		</div>

		<div class="w-size7 p-t-30 p-l-15 p-r-15 respon4 col-1 text-justify">
			<div class="flex-m p-t-30">
				<a href="#" class="fs-18 color1 p-r-20 fa fa-facebook"></a>
				<a href="#" class="fs-18 color1 p-r-20 fa fa-instagram"></a>
				<a href="#" class="fs-18 color1 p-r-20 fa fa-pinterest-p"></a>
				<a href="#" class="fs-18 color1 p-r-20 fa fa-snapchat-ghost"></a>
				<a href="#" class="fs-18 color1 p-r-20 fa fa-youtube-play"></a>
			</div>
		</div>

			<!-- <div class="w-size7 p-t-30 p-l-15 p-r-15 respon4">
				<h4 class="s-text12 p-b-30">
					Links
				</h4>

				<ul>
					<li class="p-b-9">
						<a href="#" class="s-text7">
							Search
						</a>
					</li>

					<li class="p-b-9">
						<a href="#" class="s-text7">
							About Us
						</a>
					</li>

					<li class="p-b-9">
						<a href="#" class="s-text7">
							Contact Us
						</a>
					</li>

					<li class="p-b-9">
						<a href="#" class="s-text7">
							Returns
						</a>
					</li>
				</ul>
			</div>

			<div class="w-size7 p-t-30 p-l-15 p-r-15 respon4">
				<h4 class="s-text12 p-b-30">
					Help
				</h4>

				<ul>
					<li class="p-b-9">
						<a href="#" class="s-text7">
							Track Order
						</a>
					</li>

					<li class="p-b-9">
						<a href="#" class="s-text7">
							Returns
						</a>
					</li>

					<li class="p-b-9">
						<a href="#" class="s-text7">
							Shipping
						</a>
					</li>

					<li class="p-b-9">
						<a href="#" class="s-text7">
							FAQs
						</a>
					</li>
				</ul> -->
			</div>

			<!-- <div class="w-size8 p-t-30 p-l-15 p-r-15 respon3">
				<h4 class="s-text12 p-b-30">
					Newsletter
				</h4>

				<form>
					<div class="effect1 w-size9">
						<input class="s-text7 bg6 w-full p-b-5" type="text" name="email" placeholder="email@example.com">
						<span class="effect1-line"></span>
					</div>

					<div class="w-size2 p-t-20">
						<!-- Button -->
						<!-- <button class="flex-c-m size2 bg4 bo-rad-23 hov1 m-text3 trans-0-4">
							Subscribe
						</button>
					</div>

				</form>
			</div> --> 
		</div>

		<div class="t-center p-l-15 p-r-15">
			

			<div class="t-center s-text8 p-t-20">
				Copyright © SiBengkel 
			</div>
		</div>
	</footer>



	<!-- Back to top -->
	<div class="btn-back-to-top bg0-hov" id="myBtn">
		<span class="symbol-btn-back-to-top">
			<i class="fa fa-angle-double-up" aria-hidden="true"></i>
		</span>
	</div>

	<!-- Container Selection -->
	<div id="dropDownSelect1"></div>
	<div id="dropDownSelect2"></div>

	<!--===============================================================================================-->
	<script type="text/javascript" src="<?php echo e(asset ('vendor/jquery/jquery-3.2.1.min.js')); ?>"></script>
	<!--===============================================================================================-->
	<script type="text/javascript" src="<?php echo e(asset ('vendor/animsition/js/animsition.min.js')); ?>"></script>
	<!--===============================================================================================-->
	<script type="text/javascript" src="<?php echo e(asset ('vendor/bootstrap/js/popper.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset ('vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
	<!--===============================================================================================-->
	<script type="text/javascript" src="<?php echo e(asset ('vendor/select2/select2.min.js')); ?>"></script>
	<script type="text/javascript">
		$(".selection-1").select2({
			minimumResultsForSearch: 20,
			dropdownParent: $('#dropDownSelect1')
		});

		$(".selection-2").select2({
			minimumResultsForSearch: 20,
			dropdownParent: $('#dropDownSelect2')
		});
	</script>
	<!--===============================================================================================-->
	<script type="text/javascript" src="<?php echo e(asset ('vendor/daterangepicker/moment.min.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset ('vendor/daterangepicker/daterangepicker.js')); ?>"></script>
	<!--===============================================================================================-->
	<script type="text/javascript" src="<?php echo e(asset ('vendor/slick/slick.min.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset ('js/slick-custom.js')); ?>"></script>
	<!--===============================================================================================-->
	<script type="text/javascript" src="<?php echo e(asset ('vendor/sweetalert/sweetalert.min.js')); ?>"></script>
	<script type="text/javascript">
		$('.block2-btn-addcart').each(function(){
			var nameProduct = $(this).parent().parent().parent().find('.block2-name').html();
			$(this).on('click', function(){
				swal(nameProduct, "is added to cart !", "success");
			});
		});

		$('.block2-btn-addwishlist').each(function(){
			var nameProduct = $(this).parent().parent().parent().find('.block2-name').html();
			$(this).on('click', function(){
				swal(nameProduct, "is added to wishlist !", "success");
			});
		});
	</script>

	<!--===============================================================================================-->
	<script src="<?php echo e(asset ('js/main.js')); ?>"></script><?php /**PATH C:\xampp\htdocs\TA\resources\views/layout/footer.blade.php ENDPATH**/ ?>