


<?php $__env->startSection('title'); ?>
    Daftar Booking | Mitra SiBengkel
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

<div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <h4 class="card-title"> Daftar Booking</h4>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table">
                    <thead class=" text-primary">
                      <th>ID</th>
                      <th>Nama</th>
                      <th>Jenis Service</th>
                      <th>Jadwal Booking</th>
                      <th>Action</th>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $tb_booking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          
                      
                      <tr>
                        <td><?php echo e($row->id); ?></td>
                        <td><?php echo e($row->nama); ?></td>
                        <td><?php echo e($row->jenis_service); ?> </td>
                        <td><?php echo e($row->jadwal); ?></td>
                        <td>
                          <a href="#" class="btn btn-danger">DELETE</a>
                        </td>
                      </tr>
                      
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
          
            </div>
          </div>
        </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BlogLaravel\resources\views/admin/booking.blade.php ENDPATH**/ ?>